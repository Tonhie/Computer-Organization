.text
	move $2, $0
	li $3, 1
	li $4, 4
	subi $4, $4, 2
init_loop:
	addu $1, $2, $3
	move $2, $3
	move $3, $1
	subiu $4, $4, 1
	bnez $4, init_loop
