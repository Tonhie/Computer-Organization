.text
main:
    addiu $2, $0, 25
    addiu $3, $0, 7
    addiu $4, $0, 64
    addiu $5, $0, 12
    addiu $6, $0, 3
outer_loop:
    addiu $t9, $0, 0
    slt $t0, $3, $2
    beq $t0, $0, skip1
    add $t1, $2, $0
    add $2, $3, $0
    add $3, $t1, $0
    addiu $t9, $0, 1
skip1:
    slt $t0, $4, $3
    beq $t0, $0, skip2
    add $t1, $3, $0
    add $3, $4, $0
    add $4, $t1, $0
    addiu $t9, $0, 1
skip2:
    slt $t0, $5, $4
    beq $t0, $0, skip3
    add $t1, $4, $0
    add $4, $5, $0
    add $5, $t1, $0
    addiu $t9, $0, 1
skip3:
    slt $t0, $6, $5
    beq $t0, $0, skip4
    add $t1, $5, $0
    add $5, $6, $0
    add $6, $t1, $0
    addiu $t9, $0, 1
skip4:
    bne $t9, $0, outer_loop 
end:
    li $v0, 10
