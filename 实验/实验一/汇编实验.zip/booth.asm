.data
msg1: .asciiz "Multiplicand: "
msg2: .asciiz "Multiplier: "
msg3: .asciiz "Product (high 32 bits): "
msg4: .asciiz "Product (low 32 bits): "
newline: .asciiz "\n"
.text
.globl main
main:
li $t0, 7
li $t1, -3
move $a0, $t0
move $a1, $t1
jal booth_multiply
move $s0, $v0
move $s1, $v1
li $v0, 4
la $a0, msg1
syscall
li $v0, 1
move $a0, $t0
syscall
li $v0, 4
la $a0, newline
syscall
li $v0, 4
la $a0, msg2
syscall
li $v0, 1
move $a0, $t1
syscall
li $v0, 4
la $a0, newline
syscall
li $v0, 4
la $a0, msg3
syscall
li $v0, 1
move $a0, $s0
syscall
li $v0, 4
la $a0, newline
syscall
li $v0, 4
la $a0, msg4
syscall
li $v0, 1
move $a0, $s1
syscall
li $v0, 4
la $a0, newline
syscall
li $v0, 10
syscall
booth_multiply:
addi $sp, $sp, -20
sw $ra, 16($sp)
sw $s0, 12($sp)
sw $s1, 8($sp)
sw $s2, 4($sp)
sw $s3, 0($sp)
move $s0, $a0
move $s1, $a1
li $s2, 0
move $s3, $s1
li $t0, 0
li $t1, 32
booth_loop:
andi $t2, $s3, 1
beq $t2, $t0, no_add_sub
beq $t2, $0, add_mcand
sub $s2, $s2, $s0
j no_add_sub
add_mcand:
add $s2, $s2, $s0
no_add_sub:
andi $t3, $s2, 1
sra $s2, $s2, 1
srl $s3, $s3, 1
sll $t3, $t3, 31
or $s3, $s3, $t3
move $t0, $t2
addi $t1, $t1, -1
bnez $t1, booth_loop
move $v0, $s2
move $v1, $s3
lw $s3, 0($sp)
lw $s2, 4($sp)
lw $s1, 8($sp)
lw $s0, 12($sp)
lw $ra, 16($sp)
addi $sp, $sp, 20
jr $ra